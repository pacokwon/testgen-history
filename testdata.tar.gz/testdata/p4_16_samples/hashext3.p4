/*
Copyright 2024 Intel Corp.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

enum HashAlgorithm_t {
    IDENTITY,
    RANDOM
}

@pure extern HashAlgorithm_t identity_hash(bool msb, bool extend);
@pure extern HashAlgorithm_t random_hash(bool msb, bool extend);

extern Hash<W> {
    /// Constructor
    /// @type_param W : width of the calculated hash.
    /// @param algo : The default algorithm used for hash calculation.
    Hash(HashAlgorithm_t algo);

    /// Compute the hash for the given data.
    /// @param data : The list of fields contributing to the hash.
    /// @return The hash value.
    W get<D>(in D data);
}

header h1_t {
    bit<32>     f1;
    bit<32>     f2;
    bit<32>     f3;
}

struct hdrs {
    h1_t        h1;
    bit<16>     hash;
}

control test(inout hdrs hdr) {
    apply {
        hdr.hash = Hash<bit<16>>(random_hash(false, false)).get(hdr.h1);
    }
}
